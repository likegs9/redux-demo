/**
 * Created by chenhf on 16-3-21.
 */
require('babel-register')
require('./server')