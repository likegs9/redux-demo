module.exports = () => {
  return {
    'primary-color': '#EE7CB2',
    'link-color': '#EE7CB2',
    'border-radius-base': '2px',
  };
};