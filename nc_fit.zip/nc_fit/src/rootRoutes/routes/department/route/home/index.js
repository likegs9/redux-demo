
import Home from '../../../../../app/department/home/containers/index.js'
 
  const route = {
   path: 'department',
   getComponents(location, callback) {
    require.ensure([], function (require) {
      callback(null, Home)
    })
  }
 }
 
 export default route