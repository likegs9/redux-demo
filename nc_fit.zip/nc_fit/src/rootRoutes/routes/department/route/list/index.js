
import List from '../../../../../app/department/list/containers/index.js'

 const route = {
  path: '/list',
  getComponents(location, callback) {
   require.ensure([], function (require) {
     callback(null, List)
   })
 }
}

export default route