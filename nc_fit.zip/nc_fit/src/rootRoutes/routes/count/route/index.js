
import Counter from '../../../../app/demo/counter/containers/index.jsx'

 const route = {
  path: 'Counter',
  getComponents(location, callback) {
   require.ensure([], function (require) {
     callback(null, Counter)
   })
 }
}

export default route