
import project from './routes/project';
import department from './routes/department/route/home/index.js';
import departList from './routes/department/route/list/index.js';
import count from './routes/count/route/index.js'
import app from 'app';

const rootRoutes = {
  childRoutes: [
    {
      path: '/login',
      getComponents(location, callback) {
        require.ensure([], function (require) {
          callback(null, require('app/login/main/containers'))
        })
      },
    }, {
      path: '/',
      getComponents(location, callback) {
        require.ensure([], function (require) {
          callback(null, app)
        })
      },
      childRoutes: [
        project,
        department,
        departList,
        count
      ]
    }
  ]
}

export default rootRoutes