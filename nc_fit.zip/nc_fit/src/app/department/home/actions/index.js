
export function listadd(list,fn){
    return(dispatch,getState)=>{
        setTimeout(()=>{
           dispatch({type:'LISTADD',list,fn})
        },1000)
    }
}

export function listdel(index,fn){
    return(dispatch,getState)=>{
        setTimeout(()=>{
           dispatch({type:'LISTDEL',index})
           fn()
        },1000)
    }
}

export function listchange(value,index,fn){
    return(dispatch,getState)=>{
        setTimeout(()=>{
           dispatch({type:'LISTCHANGE',value,index})
           fn()
        },1000)
    }
}