import  React, { Component } from 'react';
import './index.less'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux';
import * as Actions from '../actions/index.js'
import demoReducers from '../reducers/index.js'
import { Form, Icon, Input, Button, Checkbox,Col,DatePicker ,message,Select,Spin,TimePicker} from 'antd';
const FormItem = Form.Item;
import moment from 'moment';

import debounce from 'lodash.debounce';
const Option = Select.Option;


function handleChange(value) {
    console.log(`selected ${value}`);
  }
  
  function handleBlur() {
    console.log('blur');
  }
  
  function handleFocus() {
    console.log('focus');
  }
  

class NormalLoginForm extends React.Component {
    constructor(props){
        super(props);
        this.state={
            value:'1111'
        }
    }
    handleSubmit = (e) => {
      e.preventDefault();
      let that=this;
      this.props.form.validateFields((err, values) => {
        if (!err) {
            let fn=()=>{
                for(var key in values){
                    this.props.form.setFieldsValue({
                        [key]: '',
                      });
                }
                message.success('增加项目成功');
            }
            for(var key in values){
                if(key === 'dateStart'){
                    if(typeof values[key] !== 'string'){
                        values[key]=values[key]._d.toLocaleDateString().replace(/\//g,'-');
                    }          
                }else if(key === 'endTime'){
                    if(typeof values[key] !== 'string'){
                        values[key]=values[key]._d.toLocaleDateString().replace(/\//g,'-');
                    }
                }
            }
            that.props.add(values,fn);    
        }
    
      });
    }
 
    render() {
      const { getFieldDecorator } = this.props.form;
      return (
        <div>
            <Form onSubmit={this.handleSubmit}  className="login-form home-form" >

            <FormItem>
                {getFieldDecorator('number', {
                rules: [{ required: true, message: '请输入编号!' }],
                })(
                <Input prefix={<Icon type="tag-o" style={{ fontSize: 13 }}/>} type='text' placeholder="请输入编号!"/>
                )}
            </FormItem>

            <FormItem >
                {getFieldDecorator('projectName', {
                rules: [{ required: true, message: '请输入项目名称' }],
                })(
                <Input prefix={<Icon type="folder" style={{ fontSize: 13 }}/>} type="text" placeholder="请输入项目名称"/>
                )}
            </FormItem>

            <FormItem >
                {getFieldDecorator('projectDiscribe', {
                rules: [{ required: true, message: '请输入项目描述' }],
                })(
                <Input prefix={<Icon type="edit"  style={{ fontSize: 13 }}/>} type="text" placeholder="请输入项目描述"/>
                )}
            </FormItem>

            <FormItem >
                    <Col span={10}>
                        <FormItem label="起始时间">
                        {getFieldDecorator('dateStart', {
                        rules: [{ required: true, message: '请输入事件' }],
                        })(
                            <DatePicker />
                        )}
                        </FormItem>  
                       
                    </Col>
                
                    <Col span={10}>
                        <FormItem label="结束时间">
                        {getFieldDecorator('endTime', {
                        rules: [{ required: true, message: '请输入事件' }],
                        })(
                           <DatePicker />
                        )}
                        </FormItem>  
                    </Col>
            </FormItem>

            <FormItem >
                {getFieldDecorator('partInPeople', {
                rules: [{ required: true, message: '请输入参与人' }],
                })(
                <Input prefix={<Icon type="user" style={{ fontSize: 13 }} />} type="text" placeholder="请输入参与人" />
                )}
            </FormItem>

            <FormItem >
                {getFieldDecorator('partIn', {
                rules: [{ required: true, message: '请输入参与部门' }],
                })(
                <Input prefix={<Icon type="user" style={{ fontSize: 13 }} />} type="text" placeholder="请输入参与部门"/>
                )}
            </FormItem>

            <FormItem>
                <Button type="primary" htmlType="submit" >
                增加
                </Button>

            </FormItem>
            </Form>
        </div>
      );
    }
  }

const WrappedNormalLoginForm = Form.create()(NormalLoginForm);

function onChange(time, timeString) {
  console.log(time, timeString);
}
function d(time) {
  console.log(time,'d');
}
class Home extends Component {
    constructor(props){
        super(props);
        this.state={
            add:props.demoAction.listadd
        }
    }
    render() {
        return (
            <div className='home-warrper'>
               <h5>新建项目</h5>
               <WrappedNormalLoginForm add={this.state.add}/>
            </div>
        );
    }
}

export default connect(
    state=>{
        return{
            demo:state.demoReducers
        }
    },
    dispatch=>{
        return{
            demoAction:bindActionCreators(Actions,dispatch)
        }
    }
)(Home)

