import Immutable from 'immutable'
let ary=[{keyindex:'1',value:2},{keyindex:'1',value:2}]
let $$initialState = {
	loginState: {login:false,username:'gaoshan'},
	listData:[{
		key: 1,
		number: '0001',
		projectName: 'John Brown',
		projectDiscribe: 'New York No. 1 Lake Park',
		dateStart: '2017-07-15',
		endTime:'2017-07-18',
		partIn:'部门1',
		setMyself:{},
		partInPeople:'人员1'
	  },
	  {
		key: 2,
		number: '0002',
		projectName: 'John Brown',
		projectDiscribe: 'New York No. 1 Lake Park',
		dateStart: '2017-07-15',
		endTime:'2017-07-18',
		partIn:'部门1',
		setMyself:{},
		partInPeople:'人员1'
	  },
	  {
		key: 3,
		number: '0003',
		projectName: 'John Brown',
		projectDiscribe: 'New York No. 1 Lake Park',
		dateStart: '2017-07-15',
		endTime:'2017-07-18',
		partIn:'部门1',
		setMyself:{},
		partInPeople:'人员1'
	  }
	]
};
export default function demoReducers($$state = Immutable.fromJS($$initialState), action){
	switch (action.type) {	
		case 'LOGIN':
		//$$state.setIn([loginState,login])
			let stateNew =$$state.toJS()
			stateNew.loginState.login=true
			return Immutable.fromJS(stateNew)	
			break;
		case 'LOGINOUT':
			stateNew =$$state.toJS()
			stateNew.loginState.login=false
			return Immutable.fromJS(stateNew)	
			break;
		case 'LISTADD':
			stateNew =$$state.toJS();
			
			let listLength=stateNew.listData.length;
			if(listLength===0){
				let key=1;
				action.list.key=key
			}else{
				let key=stateNew.listData[listLength-1].key+1;
				action.list.key=key
			}
			stateNew.listData=[...stateNew.listData,action.list]
			action.fn()
			return Immutable.fromJS(stateNew)	
			break;	
		case 'LISTDEL':
			let delNew =$$state.toJS();
			delNew.listData=delNew.listData.filter((item,indexItem)=>{
				return indexItem!==action.index
			})
			return Immutable.fromJS(delNew)	
			break;
		case 'LISTCHANGE':
		   let changeNew = $$state.toJS();
		   let changekey=changeNew.listData[action.index].key
		   changeNew.listData[action.index]=action.value;
		   changeNew.listData[action.index].key=changekey
			return Immutable.fromJS(changeNew)	
			break;	
	    default: 
	        return $$state;
    }
}
