import  React, { Component } from 'react';
import { Table, Icon,Button ,Form,  Input,  Checkbox,Col,DatePicker,message } from 'antd';
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux';
import * as Actions from '../../home/actions/index.js'
import demoReducers from '../../home/reducers/index.js'
const FormItem = Form.Item;
import moment from 'moment';
import './index.less'
import Department from '../../../common/selectPerson/index.jsx'

class NormalLoginForm extends React.Component {
    constructor(props){
        super(props);
        this.state={}
    }
    componentDidMount(){
        this.setState({
            data:this.props.data
        },()=>{
            let data=this.state.data;
            for(var key in data){
                if(key ==='dateStart'){
                    this.props.form.setFieldsValue({
                        [key]: moment(data[key], 'YYYY-MM-DD')
                    });
                }else if(key === 'endTime'){
                    this.props.form.setFieldsValue({
                        [key]: moment(data[key], 'YYYY-MM-DD')
                    });
                }else{
                    this.props.form.setFieldsValue({
                        [key]: data[key],
                    });
                }
              }
        })
    }
    
    handleSubmit = (e) => {
      e.preventDefault();
      let that=this;
      this.props.form.validateFields((err, values) => {
        if (!err) {
            let closeFn=()=>{
                this.props.closeModel();
                message.success('修改成功');
            }
            for(var key in values){
                if(key ==='dateStart'){
                    values[key]=values[key]._d.toLocaleDateString().replace(/\//g,'-');
                }else if(key === 'endTime'){
                    values[key]=values[key]._d.toLocaleDateString().replace(/\//g,'-');
                }
            }
            this.props.onSubmit.listchange(values,this.props.index,closeFn);
        }
      });
    }
   
   
    render() {
      const { getFieldDecorator } = this.props.form;
      const {data} = this.state;
      return (
          <div>
              {
                  data?
                  <div>
                        <Form onSubmit={this.handleSubmit}  className="login-form home-form" >

                        <FormItem>
                            {getFieldDecorator('number', {
                            rules: [{ required: true, message: '请输入编号!' }],
                            })(
                            <Input prefix={<Icon type="tag-o" style={{ fontSize: 13 }}/>} type='text' placeholder="请输入编号!"/>
                            )}
                        </FormItem>

                        <FormItem >
                            {getFieldDecorator('projectName', {
                            rules: [{ required: true, message: '请输入项目名称' }],
                            })(
                            <Input prefix={<Icon type="folder" style={{ fontSize: 13 }}/>} type="text" placeholder="请输入项目名称"/>
                            )}
                        </FormItem>

                        <FormItem >
                            {getFieldDecorator('projectDiscribe', {
                            rules: [{ required: true, message: '请输入项目描述' }],
                            })(
                            <Input prefix={<Icon type="edit"  style={{ fontSize: 13 }}/>} type="text" placeholder="请输入项目描述"/>
                            )}
                        </FormItem>

                        <FormItem style={{height:"70px"}}>
                                <Col span={10}>
                                    <FormItem label="起始时间">
                                    {getFieldDecorator('dateStart', {
                                    rules: [{ required: true, message: '请输入编号!' }],
                                    })(
                                        <DatePicker />
                                    )}
                                    </FormItem>
                                </Col>
                            
                                <Col span={10}>
                                    <FormItem label="结束时间">
                                    {getFieldDecorator('endTime', {
                                    rules: [{ required: true, message: '请输入编号!' }],
                                    })(
                                        <DatePicker/>
                                    )}
                                    </FormItem>
                                </Col>
                        </FormItem>

                        <FormItem >
                            {getFieldDecorator('partInPeople', {
                            rules: [{ required: true, message: '请输入参与人' }],
                            })(
                            <Input prefix={<Icon type="user" style={{ fontSize: 13 }} />} type="text" placeholder="请输入参与人" />
                            )}
                        </FormItem>

                        <FormItem >
                            {getFieldDecorator('setMyself', {
                                rules: [{ required: true, message: '自定义' }],
                            })(
                                 <Myself/>
                            )}
                        </FormItem>

                        <FormItem >
                            {getFieldDecorator('partIn', {
                            rules: [{ required: true, message: '请输入参与部门' }],
                            })(
                            <Input prefix={<Icon type="user" style={{ fontSize: 13 }} />} type="text" placeholder="请输入参与部门"/>
                            )}
                        </FormItem>

                        <FormItem>
                            <Button type="primary" htmlType="submit" >
                                修改
                            </Button>
                        </FormItem>
                    </Form>
                </div>:''
           }
        </div>
      );
    }
  }

const WrappedNormalLoginForm = Form.create()(NormalLoginForm);

class Myself extends Component{
    constructor(props){
        super(props);
        const value=this.props.value || {}
        this.state={
            title:'',
            visible:false,
        }
    }
    fo(){
        this.setState({
            visible:true
        })
    }
    ok(data){
        this.setState({
            title:data,
            visible:false
        },()=>{
            this.props.onChange(Object.assign({},this.state,{title:this.state.title}))
        })
    }
    cancel(){
        this.setState({
            visible:false
        })
    }
    render(){
        //自定义验证组件，必须触发默认父级传过来的this.props.onChange方法，通过这个方法把获取到的值通过state保存
        let s={width:"550px",height:"600px",zIndex:10000}
        let data;
        if(this.props.value!=null&&this.props.value!='{}'){
            data= this.props.value.title;
        }    
        return(
            <div>
                <Modal 
                    title="修改"
                    visible={this.state.visible}
                    sizeStyle={s}
                    closeModel={this.cancel.bind(this)}
                >
                <Department
                    async = {true}
                    multi={false}
                    options={{url:'http://localhost:5000/list'}}
                    onOk={this.ok.bind(this)}
                    onCancel={this.cancel.bind(this)}
                    selectKeys={this.props.value}
                />
                </Modal>
                   
                <input value={this.props.value?this.props.value:''} ></input>
                <div onClick={this.fo.bind(this)} className="department-chioce">
                    {data?
                    data.map((item,inde)=>{
                        return (
                            <span>{item.title}</span>
                        )
                    }):'请选择部门'}
                    
                </div>
            </div>
        )
    }
}


class Modal  extends Component {
    constructor(props){
        super(props)
    }
    del(){
      this.props.closeModel()    
    }
    render(){
        let {visible,sizeStyle} =this.props
       
        return(
            <div>
            { visible?
                <div  className='model-mask' style={sizeStyle?{zIndex:sizeStyle.zIndex}:{}}>
                    {
                        <div className='model-mask-inner'  style={{...sizeStyle}}>
                            <h3>
                                <span className='mask-del' onClick={this.del.bind(this)}><Icon type="close" style={{ fontSize: 13 }} /></span>
                                {this.props.title}
                            </h3>
                            {this.props.children}
                        </div>
                    }
                 
                </div>
                :
             ''}
           </div>
        )
    }

}

class List extends Component {
    constructor(){
        super();
        this.state={
            val:'',
            visible:false,
            confirmLoading:false,
            panel:false,
            index:0,
            value:''
        }
        
        this.columns = [{
            title: '编号',
            dataIndex: 'number',
            key: 'number',
            render: (text,record, index )=> {
                return <div onClick={this.changeLeft.bind(this,text,index)}>{text}</div>
            },
          }, {
            title: '项目名称',
            dataIndex: 'projectName',
            key: 'projectName',
          }, {
            title: '项目描述',
            dataIndex: 'projectDiscribe',
            key: 'projectDiscribe',
          }
          , {
            title: '起始时间',
            dataIndex: 'dateStart',
            key: 'dateStart',
          }
          , {
            title: '结束时间',
            dataIndex: 'endTime',
            key: 'endTime',
          }
          , {
            title: '参与部门',
            dataIndex: 'partIn',
            key: 'partIn',
          },
          {
            title: '参与人员',
            dataIndex: 'setMyself',
            key: 'setMyself',
          },
          {
            title: '参与人员',
            dataIndex: 'partInPeople',
            key: 'partInPeople',
          },
          {
            title: '操作',
            key: 'action',
            render: (text, record,index) => (
              <div>
                <Button type="danger" htmlType="button" onClick={()=>{this.itemDelete(index)}}>删除</Button>
                <Button type="danger" htmlType="button" onClick={()=>{this.showModal(index)}}>修改</Button>
              </div>
            ),
          }];  
    }
    changeLeft(text,index){
        this.setState({
            panel:true,
            index,
            value:text
        })
    }
    hideChangeLeft(){
        this.setState({
            panel:false,
        })
    }
    showModal(index){
        let data=this.props.demo.toJS().listData[index]
        this.setState({
          visible: true,
          index,
          data
        });
    }
   
    handleCancel(){
        this.setState({
            visible: false,
        });
    }
    itemDelete(index){
          let delFn=()=>{
             message.success('删除成功');
          }
           this.props.demoAction.listdel(index,delFn)
    }
    render() {
        let data = this.props.demo.toJS();
        
        const { visible, confirmLoading} = this.state;

        return (
            <div className='list-warpper'>
                <h2>项目列表</h2>
                <Table columns={this.columns} dataSource={data.listData}/>
                <div className={this.state.panel?'show-panel swiper-left':'swiper-outleft hide-panel '}>
                    <div className='hide-panel-inner'>
                        <Button type='button' onClick={this.hideChangeLeft.bind(this)}>关闭</Button>
                        {this.state.value}
                    </div>
                </div>
                <Modal 
                    title="修改"
                    visible={visible}
                    closeModel={this.handleCancel.bind(this)}
                >
                    <WrappedNormalLoginForm 
                        data={this.state.data} 
                        index={this.state.index} 
                        onSubmit={this.props.demoAction} 
                        closeModel={this.handleCancel.bind(this)}
                    />
                </Modal>
            </div>
        );
    }
}


export default connect(
    state=>{
        return{
            demo:state.demoReducers
        }
    },
    dispatch=>{
        return{
            demoAction:bindActionCreators(Actions,dispatch)
        }
    }
)(List)




