import Immutable from 'immutable'
let initialState = {
	number:0
};
//$$state为immutable对象，为区分js对象变量名加$$
export default function counterReducers($$state =Immutable.fromJS(initialState) , action){
	switch (action.type) {	
		case 'ADD':
			let a=$$state.set('number',$$state.get('number')+1);
			//必须返回新的state对象
			return $$state.merge(a)
		break;
		case 'MIN':
			let b=$$state.set('number',$$state.get('number')-1)
			return $$state.merge(b)
		break;
	    default: 
	        return $$state;
    }
}

