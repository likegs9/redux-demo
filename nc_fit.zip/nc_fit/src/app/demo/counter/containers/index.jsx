import React, { Component } from 'react';
import { Input, Button} from 'antd';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

//bindActionCreators版
import * as Actions from '../actions/index.js'

//普通redux版
//import {minus,add} from '../actions/index.js'

import Immutable from 'immutable'


class Counter extends Component {
    constructor(props){
        super(props);
        this.state={
            num:0
        }
        
    }
    add(){
        //最基础班redux
        //this.props.add()

        //bindActionCreators版
       
        this.props.countDis.add()

        //state版
        // this.state.num+=1
        // this.setState({
        //     num:this.state.num
        // })
    }
    min(){
        //最基础班redux
        //this.props.minus()

        //bindActionCreators版
         this.props.countDis.minus()

        //state版
        this.state.num-=1
        this.setState({
            num:this.state.num
        })
    }
 
    render() {
        let {countState} = this.props;
        countState=countState.toJS();//redux时注释掉
        return (
            <div className='counter-warpper'>
                <div className='counter-style'>
                    {countState.number}
                    {/* {this.state.num} */}
                </div>
                <Button onClick={()=>this.min()}>-</Button>
                <Button onClick={()=>this.add()}>+</Button>
            </div>
        );
    }
}

//这部分代码 connect第一次运行时传的两个参数，为获取store中的state和定义的action
export default connect(
    state=>{
        return {
            countState:state.counterReducers //获取state中counterReducers里的数据
        }
    },
    //以下方法其中一种即可
    //最基础版 
    // dispatch=>{
    //     return{
    //         add:()=>dispatch({type:'ADD'}),
    //         minus:()=>dispatch({type:'MIN'})
    //     }
    // }
    //函数运行版
    // dispatch=>{
    //     return{
    //         add:()=>dispatch(add()),
    //         minus:()=>dispatch(minus())
    //     }
    // }
    //bindActionCreators版
    dispatch=>{
        return{
            countDis:bindActionCreators(Actions,dispatch)//使用redux中bindActionCreators方法
        }
    }
    
)(Counter)


































