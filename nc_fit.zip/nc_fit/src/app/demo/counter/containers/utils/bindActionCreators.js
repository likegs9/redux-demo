let bindActionCreators = (actions,dispatch)=>{
    let dispatchActions = {};
    for(var attr in actions){
        dispatchActions[attr] = ()=> dispatch(actions[attr]());
    }
    return dispatchActions;
}