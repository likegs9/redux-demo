//异步触发dispatch的写法，写法固定，异步操作自定，用promise、reqwest、fetch等都可以
export let add=()=>{
    return(dispatch,getState)=>{
        console.log(getState,'getState')
        setTimeout(()=>{
            dispatch({type:'ADD'})
        },1000)   
    }
}

//不异步触发dispatch的写法，固定写法
export let minus=()=>{
    return{
        type:'MIN'
    }
}



