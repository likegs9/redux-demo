import { createStore, applyMiddleware, compose } from 'redux'
import { rootReducer }  from 'rootReducer'
import thunkMiddleware from 'redux-thunk';
import createLogger from 'redux-logger';

const loggerMiddleware = createLogger();

const initialState = window.__INITIAL_STATE__;

//中间件的固定写法
let my = store => next => action =>{
    //store获取getState
    //一个中间件时next为store.dispatch
    //action：你触发dispatch时写入的是 对象 还是 方法
    return next(action);
}

let thunk = store => next => action =>{
    let {getState}=store;
    if(typeof action === 'function'){
        //把store.dispatch方法本身,传到action中
        return action(next,getState());
    }else {
        //否则直接执行store.dispatch(action);action是一个对象{type:'ADD'}
        return next(action);
    }
}

export let store = createStore( rootReducer, initialState,compose(
    applyMiddleware (thunk, loggerMiddleware,my),
    //redux可视化工具，谷歌中下载
    window.devToolsExtension ? window.devToolsExtension() :undefined
) );

