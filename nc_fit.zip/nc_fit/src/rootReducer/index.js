import {combineReducers} from 'redux'
import demoReducers from 'app/department/home/reducers/index.js'
//project目录
import login from 'app/login/main/reducers'
import counterReducers from 'app/demo/counter/reducers'
import projectList from 'app/project/list/reducers'

let rootReducer = combineReducers({
    projectList,
    login,
    demoReducers,
    //例子中用到的reducer
    counterReducers
 });

export {rootReducer}